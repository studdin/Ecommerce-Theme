<?php

namespace ElementorWpbingo\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Icons_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;
class Bwp_Marquee_Text extends Widget_Base {
	
	public function get_name() {
		return 'wpbingo-marquee-text';
	}
	
	public function get_title() {
		return __( 'Wpbingo Marquee Text', 'wpbingo' );
	}
	
	public function get_icon() {
		return 'eicon-grow';
	}
	
	public function get_categories() {
		return [ 'wpbingo' ];
	}

	
	protected function _register_controls() {

		/*-----------------------------------------------------------------------------------*/
		/*  *.  Marquee Text - Content
		/*-----------------------------------------------------------------------------------*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'wpbingo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

			$repeater = new \Elementor\Repeater();

			$repeater->add_control(
				'wpbingo_marquee_item',
				[
					'label'			=> esc_html__( 'Content', 'wpbingo'),
					'type'			=> \Elementor\Controls_Manager::TEXT,
					'label_block'	=> true,
					'dynamic'		=> [ 'active' => true ]
				]
			);

			$repeater->add_control(
				'wpbingo_marquee_link',
				[
					'label'			=> esc_html__( 'Link', 'wpbingo'),
					'type' 			=> \Elementor\Controls_Manager::URL,
					'dynamic'		=> [ 'active' => true ],
					'placeholder' => esc_html__( 'https://your-link.com', 'wpbingo' ),
					'default' => [
						'url' => '#',
					],
				]
			);


			$this->add_control(
				'wpbingo_marquee_item_strings',
				[
					'type'   	  => \Elementor\Controls_Manager::REPEATER,
					'show_label'  => true,
					'fields'      =>  $repeater->get_controls(),
					'title_field' => '{{wpbingo_marquee_item}}',
					'default'     => [
						['wpbingo_marquee_item' => esc_html__('Item #1', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #2', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #3', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #4', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #5', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #6', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #7', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #8', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #9', 'wpbingo')],
						['wpbingo_marquee_item' => esc_html__('Item #10', 'wpbingo')],
					],
				]
			);

		$this->end_controls_section();

		/*-----------------------------------------------------------------------------------*/
		/*  *.  Marquee Text/Settings - Content
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'wpbingo_section_marquee_text_settings',
			[
				'label' => esc_html__( 'Settings', 'wpbingo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'wpbingo_marquee_text_start_visible',
			[
				'label' => __( 'Start Visible', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'default' => 'true',
			]
		);

		$this->add_control(
			'wpbingo_marquee_text_duplicated',
			[
				'label' => __( 'Duplicated', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'default' => 'true',
			]
		);

		$this->add_control(
			'wpbingo_marquee_text_pause_on_hover',
			[
				'label' => __( 'Pause On Hover', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'default' => 'false',
			]
		);

		$this->add_control(
			'wpbingo_marquee_text_direction',
			[
				'label' => __( 'Direction', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left'  => __( 'Left', 'wpbingo' ),
					'right' => __( 'Right', 'wpbingo' ),
				],
			]
		);

		$this->add_control(
			'wpbingo_marquee_text_duration',
			[
				'label' => __( 'Duration', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1000,
				'max' => 100000,
				'step' => 100,
				'default' => 5000,
			]
		);

		$this->add_responsive_control(
			'wpbingo_marquee_text_gap',
			[
				'label' => __( 'Gap', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 99999,
				'step' => 1,
				'default' => 50,
				'selectors' => [
					'{{WRAPPER}} .wpbingo-marquee-text .js-marquee' => 'gap: {{VALUE}}px;display: inline-flex;flex-wrap: wrap;',
				],
			]
		);

		$this->add_control(
			'wpbingo_marquee_text_delay_before_start',
			[
				'label' => __( 'Delay Before Start', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 99999,
				'step' => 1,
				'default' => 0,
			]
		);

		$this->add_control(
			'layout',
			[
				'label' => __( 'Layout', 'wpbingo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default'  => __( 'Default', 'wpbingo' )
				],
			]
		);

		$this->end_controls_section();

		/*-----------------------------------------------------------------------------------*/
		/*  *.  Marquee Text - Style
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'wpbingo_section_marquee_text_style',
			[
				'label' => esc_html__( 'Marquee Text', 'wpbingo'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'wpbingo_marquee_text_typography',
					'label' => __('Typography', 'wpbingo'),
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
					'selector' => '{{WRAPPER}} .wpbingo-marquee-text .wpbingo-marquee-text-item',
				]
			);

			$this->add_control(
				'font_custom_title',
				[
					'label' => _x( 'Use custom fonts','wpbingo' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'On', 'elementor' ),
					'label_off' => esc_html__( 'Off', 'elementor' ),
					'default' => '',
				]
			);

			$this->add_control(
				'input_font_custom_title',
				[
					'label' => __( 'Enter your font name', 'wpbingo' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => '',
					'placeholder' => __( 'Enter your font name here', 'wpbingo' ),
					'selectors' => [
						'{{WRAPPER}} .wpbingo-marquee-text .wpbingo-marquee-text-item' => 'font-family: {{VALUE}};',
					],
					'condition'   => [
						'font_custom_title!' => '',
					]
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Text_Shadow::get_type(),
				[
					'name' => 'wpbingo_marquee_text_shadow',
					'label' => __( 'Text Shadow', 'wpbingo' ),
					'selector' => '{{WRAPPER}} .wpbingo-marquee-text *',
				]
			);

			$this->add_control(
				'wpbingo_marquee_text_color',
				[
					'label' => __( 'Color', 'wpbingo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'global' => [
						'default' => Global_Colors::COLOR_PRIMARY,
					],
					'selectors' => [
						'{{WRAPPER}} .wpbingo-marquee-text *' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'wpbingo_marquee_text_second_color',
				[
					'label' => __( 'Second Color', 'wpbingo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'global' => [
						'default' => Global_Colors::COLOR_PRIMARY,
					],
					'selectors' => [
						'{{WRAPPER}} .wpbingo-marquee-text a:nth-child(odd) *' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Background::get_type(),
				[
					'name' => 'wpbingo_marquee_text_background',
					'label' => __( 'Background', 'wpbingo' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .wpbingo-marquee-text .js-marquee .wpbingo-marquee-text-item',
					'fields_options' => [
						'background' => [
							'default' => 'classic',
						],
						'color' => [
							'global' => [
								'default' => Global_Colors::COLOR_ACCENT,
							],
						],
					],
				]
			);

			$this->add_responsive_control(
				'wpbingo_marquee_text_padding',
				[
					'label' => esc_html__( 'Padding', 'wpbingo'),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%', 'rem' ],
					'selectors' => [
						'{{WRAPPER}} .wpbingo-marquee-text .js-marquee .wpbingo-marquee-text-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};display: inline-block;',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'wpbingo_marquee_text_border',
					'label' => esc_html__( 'Border', 'wpbingo'),
					'selector' => '{{WRAPPER}} .wpbingo-marquee-text .js-marquee .wpbingo-marquee-text-item',
				]
			);
		
			$this->add_responsive_control(
				'wpbingo_marquee_text_radius',
				[
					'label' => esc_html__( 'Border Radius', 'wpbingo'),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'selectors' => [
						'{{WRAPPER}} .wpbingo-marquee-text .js-marquee .wpbingo-marquee-text-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'wpbingo_marquee_text_box_shadow',
					'exclude' => [
						'box_shadow_position',
					],
					'selector' => '{{WRAPPER}} .wpbingo-marquee-text .js-marquee .wpbingo-marquee-text-item',
				]
			);

		$this->end_controls_section();

		/*-----------------------------------------------------------------------------------*/
		/*  *.  Marquee Icon - Style
		/*-----------------------------------------------------------------------------------*/
		$this->start_controls_section(
			'wpbingo_section_icon_style',
			[
				'label' => esc_html__( 'Marquee Icon', 'wpbingo'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'selected_icon',
			[
				'label' => esc_html__( 'Icon', 'wpbingo' ),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'skin' => 'inline',
				'label_block' => false,
				'icon_exclude_inline_options' => [],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpbingo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wpbingo-marquee-text .icon svg path' => 'fill: {{VALUE}}; color: {{VALUE}};',
					'{{WRAPPER}} .wpbingo-marquee-text .icon i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'size_icon',
			[
				'label' => esc_html__( 'Size Icon', 'wpbingo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .wpbingo-marquee-text .icon svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wpbingo-marquee-text .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_position',
			[
				'label' => esc_html__( 'Icon Position', 'wpbingo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 25,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .wpbingo-marquee-text .icon' => 'top: {{SIZE}}{{UNIT}};position: relative;',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render_text( Widget_Base $instance = null ) {
		if ( empty( $instance ) ) {
			$instance = $this;
		}
		$settings = $instance->get_settings_for_display();
		$migrated = isset( $settings['__fa4_migrated']['selected_icon'] );
		$is_new = empty( $settings['icon'] ) && Icons_Manager::is_migration_allowed();
		?>
			<?php if ( ! empty( $settings['icon'] ) || ! empty( $settings['selected_icon']['value'] ) ) : ?>
			<span>
				<?php if ( $is_new || $migrated ) :
					Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] );
				else : ?>
					<i class="<?php echo esc_attr( $settings['icon'] ); ?>" aria-hidden="true"></i>
				<?php endif; ?>
			</span>
			<?php endif; ?>
		<?php
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute( 'marquee-text', 'data-direction', $settings['wpbingo_marquee_text_direction'] );
		$this->add_render_attribute( 'marquee-text', 'data-duration', $settings['wpbingo_marquee_text_duration'] );
		$this->add_render_attribute( 'marquee-text', 'data-delayBeforeStart', $settings['wpbingo_marquee_text_delay_before_start'] );
		$this->add_render_attribute( 'marquee-text', 'data-gap', $settings['wpbingo_marquee_text_gap'] );
		$this->add_render_attribute( 'marquee-text', 'data-startVisible', $settings['wpbingo_marquee_text_start_visible'] );
		$this->add_render_attribute( 'marquee-text', 'data-duplicated', $settings['wpbingo_marquee_text_duplicated'] );
		$this->add_render_attribute( 'marquee-text', 'data-pauseOnHover', $settings['wpbingo_marquee_text_pause_on_hover'] );
		$icon_svg = $this->get_settings_for_display( 'selected_icon' );
		$icon = $this->get_settings_for_display( 'icon' );
		$migrated = isset( $settings['__fa4_migrated']['selected_icon'] );
		$is_new = empty( $settings['icon'] ) && Icons_Manager::is_migration_allowed();
		extract( shortcode_atts(
			array(
				'layout'  		=> 'default',
			), $settings )
		);
		include(WPBINGO_ELEMENTOR_TEMPLATE_PATH.'bwp-marquee-text/default.php' );
	}
}
