<?php $arr = array('br' => array(), 'p' => array(), 'span' => array()); 
use Elementor\Icons_Manager;
 ?>
<div class="bwp-widget-banner <?php echo esc_html( $layout ); ?>">
	<?php  if($image): ?>	
	<div class="bg-banner banners">
		<div class="bwp-image">
			<?php  if($link): ?>
				<a href="<?php echo esc_url($link);?>"><img class="fade-in lazyload<?php if ($image_hover) { ?> elementor-animation-<?php echo esc_attr($image_hover); } ?>" src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr__("Banner Category","wpbingo"); ?>"></a>
			<?php endif;?>
		</div>
		<?php if(isset($category) && $category) : ?>
			<?php $term = get_term_by('slug', $category, 'product_cat'); ?>
			<?php if($term) : ?>
			<div class="banner-wrapper-infor">
				<div class="info">
					<div class="item-content">
						<h3 class="item-name"><a href="<?php echo get_term_link( $term->term_id, 'product_cat' ); ?>"><?php echo esc_html($term->name); ?></a></h3>
						<?php if ($show_count) { ?>
						<div class="item-count">
							<?php if($term->count == 1){?>
								<?php echo esc_attr($term->count) .'<span>'. esc_html__(' Items', 'wpbingo').'</span>'; ?>
							<?php }else{ ?>
								<?php echo esc_attr($term->count) .'<span>'. esc_html__(' Items', 'wpbingo').'</span>'; ?>
							<?php } ?>
						</div>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php endif; ?>
		<?php endif;?>
	</div>
	<?php endif;?>
</div>
