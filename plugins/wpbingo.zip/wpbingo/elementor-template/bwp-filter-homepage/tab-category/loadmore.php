<?php   
if( $category ){	
	$numberposts = (int)$numberposts;
	$count_loadmore = ceil($numberposts/$numberposts);
	$class_col_lg = ($columns == 5) ? '2-4'  : (12/$columns);
	$class_col_md = ($columns1 == 5) ? '2-4'  : (12/$columns1);
	$class_col_sm = ($columns2 == 5) ? '2-4'  : (12/$columns2);
	$class_col_xs = ($columns3 == 5) ? '2-4'  : (12/$columns3);
	$class_col = 'col-xl-'.$class_col_lg .' col-lg-'.$class_col_md .' col-md-'.$class_col_sm .' col-'.$class_col_xs; 	
	$cat_selected = '';
	$widget_id = 'tab_category_'.rand().time();	
?>
<div class="bwp-filter-homepage tab-category <?php echo esc_attr($layout); ?><?php if(!empty($show_dividers)) echo ' tab-dividers'; ?>" <?php if($style_product > 1) { ?>data-content_product="<?php echo esc_attr($style_product) ?>"<?php } ?> data-class_col = "<?php echo esc_attr($class_col); ?>"  data-showmore="<?php echo esc_attr($numberposts); ?>"data-showmore="<?php echo esc_attr($numberposts); ?>" data-numberposts = "<?php echo esc_attr($numberposts); ?>">
	<div class="bwp-filter-heading">
		<?php if(isset($title1) && $title1) { ?>
			<div class="title-block">
				<h2><?php echo esc_html($title1); ?></h2>
			</div>
		<?php } ?>
		<ul class="filter-category title-position-<?php echo esc_attr($position);?>">
			<?php
			foreach($category as $key => $cat){	?>
				<?php
				$term = get_term_by('slug', $cat, 'product_cat');
				?>
				<?php if($cat == 'all'){?>
					<li class="category <?php if( ( $key + 1 ) == 1 ){echo 'active'; $cat_selected = $cat;}?>" data-value="<?php echo esc_attr($cat); ?>">
						<a href="#<?php echo esc_attr($widget_id).'_' . $cat; ?>" data-toggle="tab">
							<?php echo esc_html__( "All", 'wpbingo'); ?>
						</a>
					</li>
				<?php }else{?>
					<?php $terms = get_term_by('slug', $cat, 'product_cat');
					if($terms) : ?>
					<li class="category <?php if( ( $key + 1 ) == 1 ){echo 'active'; $cat_selected = $cat;}?>" data-value="<?php echo esc_attr($cat); ?>">	<a class="name-category" href="#<?php echo esc_attr($widget_id).'_'. $cat; ?>" data-toggle="tab">
							<?php echo esc_html($terms->name); ?>
						</a>
					</li>
					<?php endif; ?>
				<?php }?>
			<?php } ?>
		</ul>
	</div>
	<div class="bwp-filter-content">
		<?php
		$args = array(
			'post_type' 			=> 'product',
			'post_status' 			=> 'publish',
			'posts_per_page' 		=> $numberposts,	
		);
		$tax_query = array();
		if($cat_selected != 'all'){
			$tax_query[] = array(
							'taxonomy'	=> 'product_cat',
							'field'		=> 'slug',
							'terms'		=> $cat_selected );
		}
		$meta_query = array();
		switch ($select_order) {
			case 'date':
				$args['orderby']	= 'date';
			break;
			case 'rating':
				add_filter( 'posts_clauses',  'order_by_rating_post_clauses'  );				
			break;
			case 'popularity':
				$args['meta_key']	= 'total_sales';
				$args['orderby']	= 'meta_value_num';
			break;
			case 'featured':
				$product_visibility_term_ids = wc_get_product_visibility_term_ids();
				$tax_query[] = 	array(
									'taxonomy' => 'product_visibility',
									'field'    => 'term_taxonomy_id',
									'terms'    => $product_visibility_term_ids['featured'],
								);			
			break;
		}	
		$args['tax_query'] = $tax_query;
		$args['meta_query'] = $meta_query;
		$list = new WP_Query( $args );
		$list_total = new WP_Query( $args );
		$total = $list_total->post_count;
		?>
		<ul class="filter-orderby hidden">	  
			<li data-value="<?php echo esc_attr($select_order); ?>" class="active"><?php echo esc_html($select_order); ?></li>
		</ul>
		<div class="content-product-list content-products-<?php echo esc_attr($cat_selected); ?>">
			<div class="content products-list grid row">
				<?php while($list->have_posts()): $list->the_post();
					global $product, $post, $wpdb, $average; ?>
					<div class="item <?php echo $class_col; ?>">
						<div class="item-product">
							<?php
								$template_path = WPBINGO_ELEMENTOR_TEMPLATE_PATH . 'content-product' . esc_attr($style_product) . '.php';
								if (file_exists($template_path)) {
									include($template_path);
								} else {
									include(WPBINGO_ELEMENTOR_TEMPLATE_PATH . 'content-product.php');
								}
							?>
						</div>
					</div>
				<?php endwhile; wp_reset_postdata();?>
			</div>
		</div>
	</div>
	<div class="products_loadmore" <?php if($numberposts >= $total)  ?>>
		<button type="button" class="btn btn-default loadmore" name="loadmore">
			<strong class="lds-ellipsis"><strong></strong><strong></strong><strong></strong><strong></strong></strong>
			<span class="loadmore-button-text"><?php echo esc_html__('Load more', 'wpbingo'); ?></span>
		</button>
		<input type="hidden"  data-default = "<?php echo esc_attr($count_loadmore + 1); ?>" value="<?php echo esc_attr($count_loadmore + 1); ?>" class="count_loadmore" />
	</div>	
</div>
<?php } ?>