<div class="banner" >
	<div class="banner-image">
		<a href="<?php echo get_term_link( $term->term_id, 'product_cat' ); ?>">
			<?php if (!empty($thumb1)) : ?>
				<img class="fade-in lazyload" src="<?php echo esc_url($thumb1); ?>" alt="<?php echo $term->slug ;?>"/>
			<?php else : ?>
				<img class="fade-in lazyload" src="<?php echo esc_url(get_template_directory_uri()); ?>/images/placeholder.jpg" alt="<?php echo $term->slug ;?>"/>
			<?php endif; ?>
		</a>
	</div>
	<div class="banner-info">
		<a class="button" href="<?php echo get_term_link( $term->term_id, 'product_cat' ); ?>"><?php echo esc_html($term->name); ?></a>
	</div>
</div>