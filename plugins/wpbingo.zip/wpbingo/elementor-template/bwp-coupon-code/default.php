<?php
	use Elementor\Icons_Manager;
?>
<div class="bwp-coupon-code <?php echo esc_attr($layout); ?>">
	<span class="click-to-copy none bwp-align-icon-<?php echo esc_attr($icon_align);?> <?php if ($button_hover) { ?> elementor-animation-<?php echo esc_attr($button_hover); } ?>">
		<?php if( $coupon_code) : ?>
			<div class="click-to-copy__input-wrapper">
				<input id="select-coupon" class="click-to-copy__input" value="<?php echo esc_html( $coupon_code ); ?>">
			</div>
			<div class="click-to-copy__text-icon">
				<span class="click-to-copy__text">
					<?php echo esc_html( $coupon_code ); ?>
				</span>
				<span class="click-to-copy__icon">
					<?php if ( ! empty( $settings['icon'] ) || ! empty( $settings['selected_icon']['value'] ) ) : ?>
						<?php
							if ( $is_new || $migrated ) {
								Icons_Manager::render_icon( $icon_svg );
							} else {
								echo '<i class="' . esc_attr( $icon ) . '" aria-hidden="true"></i>';
							}
						?>
					<?php endif; ?>
				</span>
			</div>
			<span class="copy_succes">
				<?php echo esc_html($copied);?>
			</span>
		<?php endif; ?>
	</span>
</div><!-- .bwp-coupon-code -->