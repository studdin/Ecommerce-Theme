<?php 
	use Elementor\Icons_Manager;
?>
<div class="wpbingo-marquee-text-widget">
	<div class="wpbingo-marquee-text <?php echo esc_html( $layout ); ?>" <?php echo $this->get_render_attribute_string('marquee-text'); ?>>
		<?php foreach ($settings['wpbingo_marquee_item_strings'] as $marquee_string) : ?>
			<a href="<?php echo esc_url($marquee_string['wpbingo_marquee_link']['url']); ?>">
				<span class="wpbingo-marquee-text-item"><?php echo wp_kses($marquee_string['wpbingo_marquee_item'], true); ?></span>
				<?php if ( ! empty( $settings['icon'] ) || ! empty( $settings['selected_icon']['value'] ) ) : ?>
					<div class="icon">
						<?php
							if ( $is_new || $migrated ) {
								Icons_Manager::render_icon( $icon_svg );
							} else {
								echo '<i class="' . esc_attr( $icon ) . '" aria-hidden="true"></i>';
							}
						?>
					</div>
				<?php endif; ?>
			</a>
		<?php endforeach; ?>
	</div>
</div>
