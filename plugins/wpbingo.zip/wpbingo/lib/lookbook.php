<?php
require_once( ABSPATH . 'wp-includes/pluggable.php' );
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
define ( 'LOOKBOOK_TABLE', 'bwp_lookbook');
define ( 'UPLOAD_FOLDER_NAME', 'bwp_lookbook');
define ( 'UPLOAD_FOLDER_NAME_THUMB', 'bwp_lookbook_thumb');
define ( 'UPLOAD_FOLDER_NAME_ORIG', 'bwp_lookbook_orig');
define ( 'WPBINGO_LOOKBOOK_PLUGIN_DIR', untrailingslashit( dirname( __FILE__ ) ) );
define ( 'WPBINGO_LOOKBOOK_PLUGIN_URL', untrailingslashit( plugins_url( '', __FILE__ ) ) );
define ( 'LOOKBOOK_UPLOAD_URL_IMAGE', WPBINGO_LOOKBOOK_PLUGIN_URL . '/lookbook/images');
define ( 'LOOKBOOK_UPLOAD_URL_THUMB', WPBINGO_LOOKBOOK_PLUGIN_URL . '/lookbook/images/'.UPLOAD_FOLDER_NAME_THUMB);
define ( 'LOOKBOOK_UPLOAD_PATH_IMAGE', WPBINGO_LOOKBOOK_PLUGIN_DIR . '/lookbook/images');
define ( 'LOOKBOOK_UPLOAD_PATH', WPBINGO_LOOKBOOK_PLUGIN_DIR . '/lookbook/images/' . UPLOAD_FOLDER_NAME);
define ( 'LOOKBOOK_UPLOAD_PATH_ORIG', WPBINGO_LOOKBOOK_PLUGIN_DIR . '/lookbook/images/' . UPLOAD_FOLDER_NAME_ORIG);
define ( 'LOOKBOOK_UPLOAD_PATH_THUMB', WPBINGO_LOOKBOOK_PLUGIN_DIR . '/lookbook/images/' . UPLOAD_FOLDER_NAME_THUMB);

global  $admin_get_handlers,$admin_post_handlers,$config;
$admin_get_handlers = array('list_lookbook','add_lookbook');
$admin_post_handlers = array('store_lookbook','del_lookbooks','del_lookbook','check_isset_product','ajax_upload','search_product');
$config = array('width'=> 1024,
				'height' => 500,
				'thumb_width'=> 100,
				'thumb_height' => 100,
			);

function admin_js(){
    wp_register_style( 'bwp-lookbook-css', plugins_url( 'lookbook/admin/css/lookbook.css', __FILE__));
    wp_enqueue_style( 'bwp-lookbook-css' );
    wp_register_script( 'jquery-annotate-js', plugins_url( 'lookbook/admin/js/jquery.annotate.js', __FILE__) );
	wp_enqueue_script('jquery-annotate-js');	
}

function lookbook_style(){
	if (!wp_style_is('bwp_lookbook_css')) {
		wp_register_style( 'bwp_lookbook_css', plugins_url('/wpbingo/assets/css/bwp_lookbook.css') );
		wp_enqueue_style('bwp_lookbook_css');
	}	
}

function lookbook_add_menu() {
	add_submenu_page( 'wpbingo', esc_html__( 'LookBook', 'wpbingo' ), esc_html__( 'LookBook', 'wpbingo' ), 'manage_options', 'lookbook', 'bwp_dashboard');
}

if ( is_admin() ) {
    if( current_user_can('manage_options') ){
        require_once WPBINGO_LOOKBOOK_PLUGIN_DIR . '/lookbook/admin/admin.php';
    }
}

function lookbook_init() {
    do_action( 'lookbook_init' );
}

add_action('wp_print_scripts', 'load_slider_scripts');

function load_slider_scripts() {
    wp_enqueue_style ('lookbook');
}

function lookbook_install () {
    global $wpdb;
	
    $table_name = $wpdb->prefix . LOOKBOOK_TABLE;
	include_once ABSPATH.'wp-admin/includes/upgrade.php';
    if($wpdb->get_var("show tables like '$table_name'") != $table_name) {

        $sql = "CREATE TABLE IF NOT EXISTS `" . $table_name . "` (
                  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                  `name` varchar(255) NOT NULL,
				  `title` varchar(255),
				  `description` varchar(255),
				  `button` varchar(255),
				  `urlbutton` varchar(255),
                  `width` smallint(5) unsigned NOT NULL,
                  `height` smallint(5) unsigned NOT NULL,		  
                  `image` varchar(255) NOT NULL,
                  `pins` text NOT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";
		if(dbDelta($sql)){
			$sql_insert = "INSERT INTO `" . $table_name . "` (`id`, `name`, `title`, `description`, `width`, `height`, `image`, `pins`) VALUES
				(140, 'Lookbook 3', '', '', 705, 810, '0_look.jpg', '[{\"id\":\"1718158517495\",\"top\":479,\"left\":147,\"width\":30,\"height\":30,\"slug\":\"barbecue-churrasco\",\"img_height\":810,\"img_width\":705,\"editable\":true},{\"id\":\"1718160288407\",\"top\":334,\"left\":483,\"width\":30,\"height\":30,\"slug\":\"chopsticks\",\"img_height\":810,\"img_width\":705,\"editable\":true},{\"id\":\"1718160315127\",\"top\":577,\"left\":580,\"width\":30,\"height\":30,\"slug\":\"ceramic-measuring-cups\",\"img_height\":810,\"img_width\":705,\"editable\":true}]'),
				(144, 'Lookbook 1', '', '', 945, 790, '0_look-2.jpg', '[{\"id\":\"1718268685689\",\"top\":273,\"left\":610,\"width\":30,\"height\":30,\"slug\":\"greenpan-craft-skillet\",\"img_height\":790,\"img_width\":945,\"editable\":true}]'),
				(145, 'Look Book 2', '', '', 1410, 618, 'look-3.jpg', '[{\"id\":\"1718338653454\",\"top\":314,\"left\":247,\"width\":30,\"height\":30,\"slug\":\"unbrokeble-hot-flask\",\"img_height\":618,\"img_width\":1410,\"editable\":true},{\"id\":\"1718338673694\",\"top\":379,\"left\":733,\"width\":30,\"height\":30,\"slug\":\"fry-pan-cooker\",\"img_height\":618,\"img_width\":1410,\"editable\":true},{\"id\":\"1718338733166\",\"top\":130,\"left\":969,\"width\":30,\"height\":30,\"slug\":\"style-vacuum-flask\",\"img_height\":618,\"img_width\":1410,\"editable\":true}]');";
			dbDelta($sql_insert);
		}
    }
    $file = new bwp_lookbook_class();
    $file->create_folder_recursive(LOOKBOOK_UPLOAD_PATH);
    $file->create_folder_recursive(LOOKBOOK_UPLOAD_PATH_THUMB);
	add_option('update2prof_notice', 0,0);
}

function lookbook_deactivate() {
    if( !function_exists( 'the_field' )) {
        update_option( 'update2prof_notice', 0 );
    }
}


/**
 * Init
 */
add_action( 'init', 'lookbook_init' );
add_action( 'admin_menu', 'lookbook_add_menu' );
add_action( 'admin_enqueue_scripts', 'admin_js' );
add_action( 'wp_enqueue_scripts', 'lookbook_style' );
